Here are several trained models.

muct/ has a set of scripts that can generate training file from MUCT database,
then you can train your own model by yourself. See muct/README.txt for details.

If you want to train you own models with your own landmark database, please 
check Wiki ( http://code.google.com/p/asmlib-opencv/wiki/BuildModel ).
